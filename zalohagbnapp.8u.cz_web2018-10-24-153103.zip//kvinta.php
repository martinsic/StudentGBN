<?php include_once "admincheck.php"; ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
	  <title>Třídy</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link href="dyzajn.css" rel="stylesheet" type="text/css">
<link href="top.css" rel="stylesheet" type="text/css">
  </head>
  <body>
	  <?php include_once "menu2.php"; ?>
	<header><center><strong> 8. leté gymnázium - Kvinta </strong></center></header>


  <table style="width: 100%; height: 30%;">

  <tr class="tabel">
        <td width="20%"> </td>
        <td width="20%"> Předměty </td>
        <td width="5%"> </td>
        <td width="20%"> Události </td>
        <td width="5%"> </td>
        <td width="20%"> Sporty </td>
        <td width="10%"> </td>
  </tr>

<tr align="left" class="tabel2">
      <td> </td>
      <td> Český jazyk </td>
      <td> </td>
      <td> Adaptační den </td>
      <td> </td>
      <td> Basketbal </td>
      <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Anglický jazyk </td>
    <td> </td>
    <td><a href="https://sites.google.com/a/gbn.cz/tv/sportovni-kurzy/lyzarsky-kurz-kvinta"> Lyžařský kurz </a></td>
    <td> </td>
    <td> Volejbal </td>
    <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Druhý cizí jazyk </td>
    <td> </td>
    <td> Výměnný pobyt - Dánsko </td>
    <td> </td>
    <td> Sbor </td>
    <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Matematika </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> Twirling </td>
    <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Fyzika </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> Atletika </td>
    <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Základy společenských věd </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> Fotbal </td>
    <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Zeměpis </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> Florbal </td>
    <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Biologie </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> Gymnastika </td>
    <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Dějepis </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Informatika </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Chemie </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> </td>
  </tr>

  <tr align="left" class="tabel2">
    <td> </td>
    <td> Hudební / výtvarná výchova </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> </td>
    <td> </td>
  </tr>
</table>



<?php if($admin_is_logged) echo <<<_HTML_
<button type="button"  data-toggle="modal" data-target="#exampleModal"> Launch demo admin </a> </button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Formulář</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="space">
        </div>
        <div class="container">
          <form>
            <label for="formular">Název</label> <label for="linka">Link</label><br>
            <i><input type="text" placeholder="Název" class="vypln"></i><br>
            <label for="formular">Typ</label><br>
            <i><input type="text" placeholder="Událost, kurz..." class="vypln"></i><br>

            <label for="formular">Datum</label><br>
            <table>
              <th>
                <tr>
                  od <select>
                    <option value="1">Leden</option>
                    <option value="2">Únor</option>
                    <option value="3">Březen</option>
                    <option value="4">Duben</option>
                    <option value="5">Květen</option>
                    <option value="6">Červen</option>
                    <option value="7">Červenec</option>
                    <option value="8">Srpen</option>
                    <option value="9">Září</option>
                    <option value="10">Říjen</option>
                    <option value="11">Listopad</option>
                    <option value="12">Prosinec</option>
                  </select>
                </tr>
                <tr>
                  do <select>
                    <option value="1">Leden</option>
                    <option value="2">Únor</option>
                    <option value="3">Březen</option>
                    <option value="4">Duben</option>
                    <option value="5">Květen</option>
                    <option value="6">Červen</option>
                    <option value="7">Červenec</option>
                    <option value="8">Srpen</option>
                    <option value="9">Září</option>
                    <option value="10">Říjen</option>
                    <option value="11">Listopad</option>
                    <option value="12">Prosinec</option>
                  </select><br>
                </tr>
              </th>
            </table>


            <label for="formular">Podrobnosti</label><br>
            <textarea rows="4" placeholder="..." class="box"></textarea><br>
            <div class="linka">
               <i><input class="linka" type="text" placeholder="odkaz" class="vypln"></i>
            </div>
            <div class="linka">
               <i><input class="linka" type="text" placeholder="koment" class="vypln"></i>
            </div>
          </form>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div> 
_HTML_;
?>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>
