<?php
$users[1] = "gymnazium@gbn.cz";
$pwds[1] = "d43e069b983df2158a3a273dd1bf3d2f5dc889ff3004e2624ec00327bee9978aa1e4c58fb900cf2f1c832cdb7b324a32aa8b32c3a45237f9791418b47ffe82d2";
$ids[1] = 1;
?>