<?php
if(isset($_COOKIE["UserCookie"]) && $_COOKIE["UserCookie"] != NULL){
  include_once "hash.php";
  $DecryptVarFromCookie = my_hash_crypt($_COOKIE["UserCookie"],'d');
  $DataFromCookie = explode("<dmx>",$DecryptVarFromCookie);
  $NowData =  $_SERVER["REMOTE_ADDR"] . date("Y-m-d");
  if ($NowData != $DataFromCookie[0]){
    setcookie("UserCookie", "", time() - 86400);
    $admin_is_logged = false;
  } else $admin_is_logged = true;
}else{
  $admin_is_logged = false;
}
?>