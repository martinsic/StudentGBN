   <a href="http://www.gbn.cz"><img class=logo alt="školní web" src="./logogbn.png"></a>
   <button id="login" type="button" class="right btn btn-primary" data-toggle="modal" data-target="#exampleModal">Přihlášení</button>
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Přihlášení</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
		<div class="modal-body">
            <div id="container">
        <form action="verify.php" method="POST" class="form">
			<div class="formgroup"><i><input type="text" name="login" required><label>Uživatelské jméno</label><span class="bar"></span></i></div>
			<div class="formgroup"><i><input type="password" name="password" required><label>Heslo</label><span class="bar"></span></i></div>
			<input type="submit" class="submit btn btn-primary" name="ok" value="Přihlásit se">
		</form>
			</div>
          </div>
        </div>
      </div>
    </div>