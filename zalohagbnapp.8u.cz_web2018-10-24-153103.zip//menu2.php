<div class="dropseznam">
	  <div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Výběr stránky
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item" href="index.php">MENU</a>
	  <a class="dropdown-item" href="./prima.php">Prima</a>
      <a class="dropdown-item" href="./sekunda.php">Sekunda</a>
      <a class="dropdown-item" href="./tercie.php">Tercie</a>
	  <a class="dropdown-item" href="./kvarta.php">Kvarta</a>
	  <a class="dropdown-item" href="./kvinta.php">Kvinta</a>
	  <a class="dropdown-item" href="./sexta.php">Sexta</a>
	  <a class="dropdown-item" href="./septima.php">Septima</a>
	  <a class="dropdown-item" href="./oktava.php">Oktáva</a>
	  <a class="dropdown-item" href="./prvak.php">První ročník</a>
	  <a class="dropdown-item" href="./druhak.php">Druhý ročník</a>
	  <a class="dropdown-item" href="./tretak.php">Třetí Ročník</a>
	  <a class="dropdown-item" href="./ctvrtak.php">Čtvrtý ročník</a>
  </div>
</div>
	  </div>