<?php
$db_host = "localhost";
$db_user = "gbn";
$db_pwd = "gbnGBN123";
$db_name = "gbn";
?>